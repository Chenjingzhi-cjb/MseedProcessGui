from .otBase import BaseTTXConverter


class table_J_S_T_F_(BaseTTXConverter):
    pass
